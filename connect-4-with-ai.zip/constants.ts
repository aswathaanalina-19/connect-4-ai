
import { Player } from './types';

export const ROWS = 6;
export const COLS = 7;
export const WINNING_LENGTH = 4;

export const PLAYER_TOKEN = Player.Human;
export const AI_TOKEN = Player.AI;

export const AI_THINKING_DELAY = 500;
