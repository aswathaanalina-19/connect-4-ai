import React from 'react';
import { BoardState, Player } from '../types';
import { ROWS, COLS } from '../constants';

interface GameBoardProps {
  board: BoardState;
  onColumnClick: (col: number) => void;
  disabled: boolean;
  lastMove: { row: number; col: number } | null;
  winningLine: Array<{ row: number; col: number }>;
}

const GameBoard: React.FC<GameBoardProps> = ({ board, onColumnClick, disabled, lastMove, winningLine }) => {
  const getPieceColor = (player: Player) => {
    switch (player) {
      case Player.Human:
        return 'bg-red-500';
      case Player.AI:
        return 'bg-yellow-400';
      default:
        return 'bg-gray-700';
    }
  };

  const isWinningCell = (row: number, col: number) => {
    return winningLine.some(pos => pos.row === row && pos.col === col);
  };

  return (
    <div className="p-4 bg-blue-800 rounded-xl shadow-2xl inline-block border-4 border-blue-900 relative">
      {/* Visual board grid */}
      <div className="grid grid-cols-7 gap-2" aria-hidden="true">
        {board.map((row, rowIndex) => (
          <React.Fragment key={rowIndex}>
            {row.map((cell, colIndex) => {
              const isLastMove = lastMove?.row === rowIndex && lastMove?.col === colIndex;
              const isWinCell = isWinningCell(rowIndex, colIndex);
              return (
                <div key={`${rowIndex}-${colIndex}`} className="w-12 h-12 md:w-16 md:h-16 flex items-center justify-center">
                  <div
                    className={`
                      w-10 h-10 md:w-14 md:h-14 rounded-full shadow-inner transition-colors duration-300
                      ${getPieceColor(cell)}
                      ${isLastMove ? 'animate-drop' : ''}
                      ${isWinCell ? 'animate-win' : ''}
                    `}
                  />
                </div>
              );
            })}
          </React.Fragment>
        ))}
      </div>

      {/* Clickable overlay */}
      <div className="absolute top-0 left-0 w-full h-full grid grid-cols-7 gap-2 p-4">
          {Array.from({ length: COLS }).map((_, colIndex) => (
            <div
              key={colIndex}
              aria-label={`Drop piece in column ${colIndex + 1}`}
              role="button"
              className={`w-full h-full rounded-lg transition-colors duration-200 ${
                !disabled ? 'cursor-pointer hover:bg-white/10' : ''
              }`}
              onClick={() => !disabled && onColumnClick(colIndex)}
            />
          ))}
      </div>
    </div>
  );
};

export default GameBoard;