
import React from 'react';
import { Difficulty } from '../types';

interface GameControlsProps {
  onNewGame: () => void;
  difficulty: Difficulty;
  setDifficulty: (d: Difficulty) => void;
  isAiThinking: boolean;
  gameOver: boolean;
}

const GameControls: React.FC<GameControlsProps> = ({ onNewGame, difficulty, setDifficulty, isAiThinking, gameOver }) => {
  const isControlDisabled = isAiThinking;

  return (
    <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-4 p-4 rounded-lg bg-gray-800/50 w-full max-w-md">
      <button
        onClick={onNewGame}
        className="w-full sm:w-auto px-6 py-2 bg-cyan-600 text-white font-semibold rounded-lg shadow-md hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-opacity-75 transition-colors duration-200 disabled:bg-gray-600 disabled:cursor-not-allowed"
        disabled={isAiThinking}
      >
        New Game
      </button>
      <div className="flex items-center gap-3">
        <label className="font-medium text-gray-300">Difficulty:</label>
        <select
          value={difficulty}
          onChange={(e) => {
            setDifficulty(Number(e.target.value) as Difficulty);
            if(gameOver) onNewGame();
          }}
          disabled={isControlDisabled}
          className="bg-gray-700 text-white rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-cyan-500 disabled:opacity-50"
        >
          <option value={Difficulty.Easy}>Easy</option>
          <option value={Difficulty.Medium}>Medium</option>
          <option value={Difficulty.Hard}>Hard</option>
        </select>
      </div>
    </div>
  );
};

export default GameControls;
