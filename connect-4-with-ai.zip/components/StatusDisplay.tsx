
import React from 'react';
import { GameStatus, Player } from '../types';
import { PLAYER_TOKEN, AI_TOKEN } from '../constants';

interface StatusDisplayProps {
  status: GameStatus;
  currentPlayer: Player;
  isAiThinking: boolean;
}

const StatusDisplay: React.FC<StatusDisplayProps> = ({ status, currentPlayer, isAiThinking }) => {
  const getStatusMessage = () => {
    if (status.gameOver) {
      if (status.winner === PLAYER_TOKEN) return <span className="text-green-400">You Win! 🎉</span>;
      if (status.winner === AI_TOKEN) return <span className="text-red-500">AI Wins! 🤖</span>;
      if (status.isDraw) return <span className="text-gray-400">It's a Draw!</span>;
    }
    if (isAiThinking) return <span className="text-yellow-400">AI is thinking...</span>;
    if (currentPlayer === PLAYER_TOKEN) return <span className="text-blue-400">Your Turn</span>;
    return '';
  };

  return (
    <div className="h-12 flex items-center justify-center mb-4">
      <p className="text-xl md:text-2xl font-semibold tracking-wide">
        {getStatusMessage()}
      </p>
    </div>
  );
};

export default StatusDisplay;
