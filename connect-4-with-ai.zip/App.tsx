import React, { useState, useEffect, useCallback } from 'react';
import { BoardState, Player, Difficulty, GameStatus } from './types';
import { ROWS, COLS, PLAYER_TOKEN, AI_TOKEN, AI_THINKING_DELAY } from './constants';
import { findBestMove } from './services/aiService';
import GameBoard from './components/GameBoard';
import GameControls from './components/GameControls';
import StatusDisplay from './components/StatusDisplay';

const createEmptyBoard = (): BoardState => Array(ROWS).fill(null).map(() => Array(COLS).fill(Player.None));

const App: React.FC = () => {
  const [board, setBoard] = useState<BoardState>(createEmptyBoard());
  const [currentPlayer, setCurrentPlayer] = useState<Player>(PLAYER_TOKEN);
  const [gameStatus, setGameStatus] = useState<GameStatus>({ gameOver: false, winner: null, isDraw: false });
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.Medium);
  const [isAiThinking, setIsAiThinking] = useState<boolean>(false);
  const [lastMove, setLastMove] = useState<{ row: number; col: number } | null>(null);
  const [winningLine, setWinningLine] = useState<Array<{ row: number; col: number }>>([]);

  const getWinningLine = useCallback((boardToCheck: BoardState, player: Player): Array<{row: number, col: number}> | null => {
    // Horizontal check
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c <= COLS - 4; c++) {
        const line = [
          {row: r, col: c}, {row: r, col: c+1}, {row: r, col: c+2}, {row: r, col: c+3}
        ];
        if (line.every(({row, col}) => boardToCheck[row][col] === player)) return line;
      }
    }
    // Vertical check
    for (let r = 0; r <= ROWS - 4; r++) {
      for (let c = 0; c < COLS; c++) {
        const line = [
          {row: r, col: c}, {row: r+1, col: c}, {row: r+2, col: c}, {row: r+3, col: c}
        ];
        if (line.every(({row, col}) => boardToCheck[row][col] === player)) return line;
      }
    }
    // Diagonal (down-right) check
    for (let r = 0; r <= ROWS - 4; r++) {
      for (let c = 0; c <= COLS - 4; c++) {
        const line = [
          {row: r, col: c}, {row: r+1, col: c+1}, {row: r+2, col: c+2}, {row: r+3, col: c+3}
        ];
        if (line.every(({row, col}) => boardToCheck[row][col] === player)) return line;
      }
    }
    // Diagonal (up-right) check
    for (let r = 3; r < ROWS; r++) {
      for (let c = 0; c <= COLS - 4; c++) {
        const line = [
          {row: r, col: c}, {row: r-1, col: c+1}, {row: r-2, col: c+2}, {row: r-3, col: c+3}
        ];
        if (line.every(({row, col}) => boardToCheck[row][col] === player)) return line;
      }
    }
    return null;
  }, []);

  const isBoardFull = (boardToCheck: BoardState): boolean => {
    return boardToCheck[0].every(cell => cell !== Player.None);
  };

  const handleNewGame = () => {
    setBoard(createEmptyBoard());
    setCurrentPlayer(PLAYER_TOKEN);
    setGameStatus({ gameOver: false, winner: null, isDraw: false });
    setIsAiThinking(false);
    setLastMove(null);
    setWinningLine([]);
  };

  const dropPiece = (board: BoardState, col: number, player: Player): { newBoard: BoardState; row: number } | null => {
    if (board[0][col] !== Player.None) return null; // Column is full
    const newBoard = board.map(row => [...row]);
    for (let r = ROWS - 1; r >= 0; r--) {
      if (newBoard[r][col] === Player.None) {
        newBoard[r][col] = player;
        return { newBoard, row: r };
      }
    }
    return null;
  };

  const handlePlayerMove = (col: number) => {
    if (gameStatus.gameOver || currentPlayer !== PLAYER_TOKEN || isAiThinking) return;

    const dropResult = dropPiece(board, col, PLAYER_TOKEN);
    if (!dropResult) return;
    
    const { newBoard, row } = dropResult;
    setBoard(newBoard);
    setLastMove({ row, col });

    const win = getWinningLine(newBoard, PLAYER_TOKEN);
    if (win) {
      setGameStatus({ gameOver: true, winner: PLAYER_TOKEN, isDraw: false });
      setWinningLine(win);
    } else if (isBoardFull(newBoard)) {
      setGameStatus({ gameOver: true, winner: null, isDraw: true });
    } else {
      setCurrentPlayer(AI_TOKEN);
      setIsAiThinking(true);
    }
  };

  useEffect(() => {
    if (currentPlayer === AI_TOKEN && !gameStatus.gameOver) {
      const timer = setTimeout(() => {
        const bestMove = findBestMove(board, difficulty);
        if (bestMove !== null) {
          const dropResult = dropPiece(board, bestMove, AI_TOKEN);
          if (dropResult) {
            const { newBoard, row } = dropResult;
            setBoard(newBoard);
            setLastMove({ row, col: bestMove });

            const win = getWinningLine(newBoard, AI_TOKEN);
            if (win) {
              setGameStatus({ gameOver: true, winner: AI_TOKEN, isDraw: false });
              setWinningLine(win);
            } else if (isBoardFull(newBoard)) {
              setGameStatus({ gameOver: true, winner: null, isDraw: true });
            } else {
              setCurrentPlayer(PLAYER_TOKEN);
            }
          }
        }
        setIsAiThinking(false);
      }, AI_THINKING_DELAY);
      return () => clearTimeout(timer);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPlayer, board, gameStatus.gameOver, difficulty, getWinningLine]);

  return (
    <div className="flex flex-col items-center min-h-screen p-4 bg-gray-900 font-sans">
        <header className="text-center mb-6">
            <h1 className="text-4xl md:text-5xl font-bold text-cyan-400 tracking-wider">
                Connect 4
            </h1>
            <p className="text-gray-400">with a Minimax AI</p>
        </header>
        <main className="flex flex-col items-center w-full">
            <GameControls
                onNewGame={handleNewGame}
                difficulty={difficulty}
                setDifficulty={setDifficulty}
                isAiThinking={isAiThinking}
                gameOver={gameStatus.gameOver}
            />
            <StatusDisplay status={gameStatus} currentPlayer={currentPlayer} isAiThinking={isAiThinking} />
            <GameBoard
                board={board}
                onColumnClick={handlePlayerMove}
                disabled={gameStatus.gameOver || currentPlayer === AI_TOKEN || isAiThinking}
                lastMove={lastMove}
                winningLine={winningLine}
            />
        </main>
        <footer className="mt-8 text-center text-gray-500 text-sm">
            <p>Built with React, TypeScript, and Tailwind CSS.</p>
            <p>AI powered by the Minimax algorithm with Alpha-Beta Pruning.</p>
        </footer>
    </div>
  );
};

export default App;