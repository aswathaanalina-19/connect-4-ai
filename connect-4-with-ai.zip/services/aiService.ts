
import { BoardState, Player } from '../types';
import { ROWS, COLS, WINNING_LENGTH, PLAYER_TOKEN, AI_TOKEN } from '../constants';

const checkWin = (board: BoardState, player: Player): boolean => {
    // Horizontal check
    for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c <= COLS - WINNING_LENGTH; c++) {
            if (board[r].slice(c, c + WINNING_LENGTH).every(p => p === player)) return true;
        }
    }
    // Vertical check
    for (let c = 0; c < COLS; c++) {
        for (let r = 0; r <= ROWS - WINNING_LENGTH; r++) {
            if (Array.from({ length: WINNING_LENGTH }, (_, i) => board[r + i][c]).every(p => p === player)) return true;
        }
    }
    // Diagonal (down-right) check
    for (let r = 0; r <= ROWS - WINNING_LENGTH; r++) {
        for (let c = 0; c <= COLS - WINNING_LENGTH; c++) {
            if (Array.from({ length: WINNING_LENGTH }, (_, i) => board[r + i][c + i]).every(p => p === player)) return true;
        }
    }
    // Diagonal (up-right) check
    for (let r = WINNING_LENGTH - 1; r < ROWS; r++) {
        for (let c = 0; c <= COLS - WINNING_LENGTH; c++) {
            if (Array.from({ length: WINNING_LENGTH }, (_, i) => board[r - i][c + i]).every(p => p === player)) return true;
        }
    }
    return false;
};

// Heuristically evaluate a window of 4 cells
const evaluateWindow = (window: Player[], piece: Player): number => {
    let score = 0;
    const opp_piece = piece === PLAYER_TOKEN ? AI_TOKEN : PLAYER_TOKEN;

    const piece_count = window.filter(p => p === piece).length;
    const opp_piece_count = window.filter(p => p === opp_piece).length;
    const empty_count = window.filter(p => p === Player.None).length;

    if (piece_count === 3 && empty_count === 1) {
        score += 100;
    } else if (piece_count === 2 && empty_count === 2) {
        score += 10;
    }

    if (opp_piece_count === 3 && empty_count === 1) {
        score -= 500;
    } else if (opp_piece_count === 2 && empty_count === 2) {
        score -= 5;
    }
    
    return score;
};

// Score the overall board state for the AI
const scorePosition = (board: BoardState, piece: Player): number => {
    let score = 0;

    // Center column preference
    const center_array = board.map(row => row[Math.floor(COLS / 2)]);
    const center_count = center_array.filter(p => p === piece).length;
    score += center_count * 3;

    // Horizontal
    for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c <= COLS - WINNING_LENGTH; c++) {
            const window = board[r].slice(c, c + WINNING_LENGTH);
            score += evaluateWindow(window, piece);
        }
    }

    // Vertical
    for (let c = 0; c < COLS; c++) {
        for (let r = 0; r <= ROWS - WINNING_LENGTH; r++) {
            const window = Array.from({ length: WINNING_LENGTH }, (_, i) => board[r + i][c]);
            score += evaluateWindow(window, piece);
        }
    }

    // Positive Diagonal
    for (let r = 0; r <= ROWS - WINNING_LENGTH; r++) {
        for (let c = 0; c <= COLS - WINNING_LENGTH; c++) {
            const window = Array.from({ length: WINNING_LENGTH }, (_, i) => board[r + i][c + i]);
            score += evaluateWindow(window, piece);
        }
    }

    // Negative Diagonal
    for (let r = WINNING_LENGTH - 1; r < ROWS; r++) {
        for (let c = 0; c <= COLS - WINNING_LENGTH; c++) {
            const window = Array.from({ length: WINNING_LENGTH }, (_, i) => board[r - i][c + i]);
            score += evaluateWindow(window, piece);
        }
    }

    return score;
};

const getValidLocations = (board: BoardState): number[] => {
    return Array.from({ length: COLS }, (_, col) => col).filter(col => board[0][col] === Player.None);
};

const dropPiece = (board: BoardState, col: number, piece: Player): BoardState => {
    const newBoard = board.map(row => [...row]);
    for (let r = ROWS - 1; r >= 0; r--) {
        if (newBoard[r][col] === Player.None) {
            newBoard[r][col] = piece;
            return newBoard;
        }
    }
    return newBoard; 
};

const isTerminalNode = (board: BoardState): boolean => {
    return checkWin(board, PLAYER_TOKEN) || checkWin(board, AI_TOKEN) || getValidLocations(board).length === 0;
};

const minimax = (board: BoardState, depth: number, alpha: number, beta: number, maximizingPlayer: boolean): [number | null, number] => {
    const valid_locations = getValidLocations(board);
    const is_terminal = isTerminalNode(board);

    if (is_terminal) {
        if (checkWin(board, AI_TOKEN)) return [null, 10000000 + depth];
        else if (checkWin(board, PLAYER_TOKEN)) return [null, -10000000 - depth];
        else return [null, 0]; // Draw
    }
    
    if (depth === 0) {
        return [null, scorePosition(board, AI_TOKEN)];
    }

    if (maximizingPlayer) {
        let value = -Infinity;
        let column: number | null = valid_locations[0];
        for (const col of valid_locations) {
            const b_copy = dropPiece(board, col, AI_TOKEN);
            const new_score = minimax(b_copy, depth - 1, alpha, beta, false)[1];
            if (new_score > value) {
                value = new_score;
                column = col;
            }
            alpha = Math.max(alpha, value);
            if (alpha >= beta) break;
        }
        return [column, value];
    } else { // Minimizing player
        let value = Infinity;
        let column: number | null = valid_locations[0];
        for (const col of valid_locations) {
            const b_copy = dropPiece(board, col, PLAYER_TOKEN);
            const new_score = minimax(b_copy, depth - 1, alpha, beta, true)[1];
            if (new_score < value) {
                value = new_score;
                column = col;
            }
            beta = Math.min(beta, value);
            if (alpha >= beta) break;
        }
        return [column, value];
    }
};

export const findBestMove = (board: BoardState, difficulty: number): number | null => {
    return minimax(board, difficulty, -Infinity, Infinity, true)[0];
};
