
export enum Player {
  None = 0,
  Human = 1,
  AI = 2,
}

export type CellState = Player;
export type BoardState = CellState[][];

export enum Difficulty {
  Easy = 2,
  Medium = 4,
  Hard = 6,
}

export interface GameStatus {
  gameOver: boolean;
  winner: Player | null;
  isDraw: boolean;
}
